#include "vmobject.h"

VMObject::VMObject(QObject* parent)
    : QObject{parent}
{
}
