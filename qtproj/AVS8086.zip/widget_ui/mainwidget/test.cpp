//#include "test.h"
//#include "ui_test.h"

//#include "filetreewidget.h"

//test::test(QWidget *parent)
//    :  QWidget(parent)
//    , ui(new Ui::test)
//{
//    ui->setupUi(this);
////    auto f = new FileTreewidget;
//    ui->verticalLayout->addWidget(f);

//}

//test::~test()
//{
//    delete ui;
//}
