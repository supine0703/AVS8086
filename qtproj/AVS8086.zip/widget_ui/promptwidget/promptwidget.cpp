//#include "promptwidget.h"
//#include "ui_promptwidget.h"

//promptwidget::promptwidget(QWidget *parent)
//    : QDialog(parent)
//    , FramelessWidget(parent, Func::Close)
//    , ui(new Ui::promptwidget)
//{
//    ui->setupUi(main_widget);


//}

//promptwidget::~promptwidget()
//{
//    delete ui;
//}
