//#ifndef PROMPTWIDGET_H
//#define PROMPTWIDGET_H

//#include <QDialog>
//#include "FramelessWidget.h"

//namespace Ui {
//class promptwidget;
//}

//class promptwidget : public QDialog, FramelessWidget
//{
//    Q_OBJECT

//public:
//    explicit promptwidget(QWidget *parent = nullptr);
//    ~promptwidget();

//private:
//    Ui::promptwidget *ui;
//};

//#endif // PROMPTWIDGET_H
